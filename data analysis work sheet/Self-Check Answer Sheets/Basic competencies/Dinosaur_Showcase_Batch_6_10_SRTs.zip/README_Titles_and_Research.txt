DINOSAUR SHOWCASE — BATCH 6
10 independent 60-second SRT scripts

These are nature-documentary showcases, not survival encounters. No "Imagine" intro, explorer, fictional chase, or character dialogue.
Each SRT contains 12 cues, 5 seconds per cue (00:00:00,000 – 00:01:00,000).
Voiceover speed varies, so retime individual captions to your finished audio if needed.

TITLES
01. Maip — The Shadow of Death — 105 words — 01_Maip_The_Shadow_of_Death.srt
02. Austroraptor — The River Raptor — 107 words — 02_Austroraptor_The_River_Raptor.srt
03. Bajadasaurus — Spikes Pointing Forward — 93 words — 03_Bajadasaurus_Spikes_Pointing_Forward.srt
04. Masiakasaurus — Teeth That Point Forward — 100 words — 04_Masiakasaurus_Teeth_That_Point_Forward.srt
05. Mononykus — The One-Clawed Dinosaur — 102 words — 05_Mononykus_The_One_Clawed_Dinosaur.srt
06. Concavenator — The Humpback Hunter — 106 words — 06_Concavenator_The_Humpback_Hunter.srt
07. Kosmoceratops — Fifteen Horns — 100 words — 07_Kosmoceratops_Fifteen_Horns.srt
08. Jakapil — The Two-Legged Tank — 108 words — 08_Jakapil_The_Two_Legged_Tank.srt
09. Yi qi — The Bat-Winged Dinosaur — 105 words — 09_Yi_qi_The_Bat_Winged_Dinosaur.srt
10. Sinosauropteryx — The Striped Shadow — 102 words — 10_Sinosauropteryx_The_Striped_Shadow.srt

RESEARCH REFERENCES
The narration distinguishes evidence from hypotheses, especially for inferred diets, behavior, skin coverings and incomplete skeletons.
Maip: https://www.nature.com/articles/s41598-022-09272-z
Austroraptor: https://pmc.ncbi.nlm.nih.gov/articles/PMC2679073/
Austroraptor - 2025 study: https://www.tandfonline.com/doi/full/10.1080/08912963.2025.2537843
Bajadasaurus: https://pubmed.ncbi.nlm.nih.gov/30718633/
Masiakasaurus: https://www.nature.com/articles/35054046
Mononykus - digging study: https://pubmed.ncbi.nlm.nih.gov/42120036/
Concavenator: https://www.nhm.ac.uk/discover/dino-directory/concavenator.html
Kosmoceratops: https://nhmu.utah.edu/kosmoceratops-richardsoni
Jakapil: https://www.nature.com/articles/s41598-022-15535-6
Yi qi: https://english.ivpp.cas.cn/rh/rp/202509/t20250902_1052235.html
Sinosauropteryx: https://australian.museum/learn/dinosaurs/fact-sheets/sinosauropteryx-prima/
