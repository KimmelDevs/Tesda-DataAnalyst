DINOSAUR SHORTS — BATCH 6: IMAGINE...
10 x 60-second subtitle scripts, 12 captions each, 5s per caption.
Hypothetical encounters are storytelling devices, not historical evidence.
SRT timings are fixed; adjust to your actual voiceover pace.

TRACK LIST:
01. Maip — The Shadow of Death  (111 words)
02. Austroraptor — The River Raptor  (111 words)
03. Bajadasaurus — Spikes Pointing Forward  (102 words)
04. Masiakasaurus — Teeth That Point Forward  (104 words)
05. Mononykus — The One-Clawed Dinosaur  (106 words)
06. Concavenator — The Humpback Hunter  (104 words)
07. Kosmoceratops — Fifteen Horns  (109 words)
08. Jakapil — The Two-Legged Tank  (110 words)
09. Yi qi — The Bat-Winged Dinosaur  (104 words)
10. Sinosauropteryx — The Striped Shadow  (105 words)

RESEARCH NOTES:
Behavior, defensive use, feeding, and flight are identified as hypotheses where unconfirmed.
Maip skull/hands are not preserved; relatives inform reconstructions.
Yi qi flight and Jakapil gait are not fully settled.

SOURCES:
Maip: https://www.nature.com/articles/s41598-022-09272-z
Austroraptor: https://pmc.ncbi.nlm.nih.gov/articles/PMC2679073/
Bajadasaurus: https://pmc.ncbi.nlm.nih.gov/articles/PMC6362061/
Masiakasaurus: https://pubmed.ncbi.nlm.nih.gov/11206544/
Mononykus: https://www.nationalgeographic.com/animals/facts/mononykus-olecranus
Concavenator: https://www.nhm.ac.uk/discover/dino-directory/concavenator.html
Kosmoceratops: https://nhmu.utah.edu/kosmoceratops-richardsoni
Jakapil: https://pmc.ncbi.nlm.nih.gov/articles/PMC9372066/
Yi qi: https://pubmed.ncbi.nlm.nih.gov/25924069/
Sinosauropteryx: https://www.nhm.ac.uk/discover/dino-directory/sinosauropteryx.html
