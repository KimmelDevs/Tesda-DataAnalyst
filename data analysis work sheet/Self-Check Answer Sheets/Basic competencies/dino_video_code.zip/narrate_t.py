import re, sys, numpy as np, soundfile as sf
sys.path.insert(0,"/home/claude/work/b5")
from cfg import V, ROOT
from kokoro_onnx import Kokoro
VOICE="af_heart"; SR=24000; TOTAL=60.0; OUT=65.0
OUTRO="Enjoyed that? Smash the like button, and subscribe for more dinosaur secrets!"
def ts(s):
    h,m,r=s.split(":"); sec,ms=r.split(","); return int(h)*3600+int(m)*60+int(sec)+int(ms)/1000
def cues(p):
    o=[]
    for blk in re.split(r"\n\s*\n",open(p,encoding="utf-8").read().strip()):
        ln=blk.strip().splitlines(); a,b=ln[1].split(" --> "); o.append((ts(a),ts(b)," ".join(ln[2:]).strip()))
    return o
def sentences(cs):
    res,cur,st=[],"",None
    for a,b,t in cs:
        if st is None: st=a
        cur=(cur+" "+t).strip()
        if re.search(r"[.?!]$",t) and not t.endswith("..."): res.append((st,cur)); cur,st="",None
    if cur: res.append((st,cur))
    return res
k=Kokoro(f"{ROOT}/tts/kokoro.onnx",f"{ROOT}/tts/voices.bin")
def speak(t,sp):
    t=t.replace("T. rex","T rex")
    return k.create(t,voice=VOICE,speed=sp,lang="en-us")[0]
import json
for v in sys.argv[1:]:
    TL=[]
    sents=sentences(cues(f"{ROOT}/b5/{V[v][0]}.srt"))
    buf=np.zeros(int((OUT+2)*SR),dtype=np.float32); prev=0.0
    for i,(st,text) in enumerate(sents):
        nxt=sents[i+1][0] if i+1<len(sents) else TOTAL
        start=max(st,prev+0.12); win=max(1.0,nxt-start-0.15)
        s=speak(text,1.0); dur=len(s)/SR
        if dur>win: s=speak(text,min(1.35,dur/win)); dur=len(s)/SR
        i0=int(start*SR); buf[i0:i0+len(s)]+=s[:len(buf)-i0]; prev=start+dur; TL.append((start,dur,text))
    buf[int(TOTAL*SR):]=0
    s=speak(OUTRO,1.0); print(v,"outro dur",len(s)/SR,flush=True)
    if len(s)/SR>4.4: s=speak(OUTRO,len(s)/SR/4.4)
    i0=int(60.4*SR); buf[i0:i0+len(s)]+=s
    buf=buf[:int(OUT*SR)]; buf=buf/(float(np.abs(buf).max()) or 1.0)*0.9
    json.dump(TL,open(f"{ROOT}/b5/tts/{v}.json","w"))
    sf.write(f"{ROOT}/b5/tts/{v}.wav",buf,SR); print("DONE",v,flush=True)
