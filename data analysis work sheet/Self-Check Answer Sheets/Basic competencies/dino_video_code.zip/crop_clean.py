# Cuts each box out of the raw 3x2 image and keeps only the main drawing (removes bits of neighbouring drawings).
import json, numpy as np
from PIL import Image
from scipy import ndimage as ndi
ROOT="/home/claude/work/b5"
B=json.load(open(f"{ROOT}/boxes.json"))
for sc,boxes in B.items():
    im=Image.open(f"{ROOT}/raw/{sc}.png").convert("RGB"); a=np.asarray(im)
    bg=np.median(np.concatenate([a[:20,:20].reshape(-1,3),a[:20,-20:].reshape(-1,3)]),axis=0)
    for i,(x,y,w,h) in enumerate(boxes):
        c=a[y:y+h,x:x+w]; ink=(np.abs(c.astype(int)-bg).sum(2)>60)
        ink=ndi.binary_dilation(ink,iterations=6)            # join strokes of one drawing
        lab,n=ndi.label(ink)
        if n>1:                                              # keep the biggest drawing, drop neighbours' bleed
            sizes=ndi.sum(ink,lab,range(1,n+1)); keep=lab==(1+int(np.argmax(sizes)))
            c=np.where(keep[...,None],c,bg.astype(np.uint8))
        Image.fromarray(c.astype(np.uint8)).save(f"{ROOT}/crops/{sc}_{i+1}.png")
