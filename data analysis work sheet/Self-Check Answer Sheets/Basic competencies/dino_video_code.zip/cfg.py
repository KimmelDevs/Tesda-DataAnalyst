import json
ROOT="/home/claude/work"
BOXES=json.load(open(f"{ROOT}/b5/boxes.json"))
V={"01":("01_Tyrannosaurus_The_King_of_the_Late_Cretaceous","tyrannosaurus_king"),
"02":("02_Allosaurus_The_Predator_Before_T_rex","allosaurus_predator"),
"03":("03_Psittacosaurus_The_Tiny_Beaked_Dinosaur_With_Bristles","psittacosaurus_bristles"),
"04":("04_Yutyrannus_The_Giant_Feathered_Tyrant","yutyrannus_feathered"),
"05":("05_Nanuqsaurus_The_Arctic_Tyrant","nanuqsaurus_arctic"),
"06":("06_Cryolophosaurus_The_Frozen_Crested_Hunter","cryolophosaurus_crest"),
"07":("07_Glacialisaurus_The_Antarctic_Giant_Before_Giants","glacialisaurus_antarctic"),
"08":("08_Imperobator_The_Southern_Raptor","imperobator_southern_raptor"),
"09":("09_Antarctopelta_Antarcticas_Armored_Dinosaur","antarctopelta_armored")}
