import json, re, sys
ROOT="/home/claude/work/b5"
def t(x): h=int(x//3600); m=int(x%3600//60); s=x%60; return f"{h}:{m:02d}:{s:05.2f}"
def build(v):
    TL=json.load(open(f"{ROOT}/tts/{v}.json"))
    ev=[]
    for start,dur,text in TL:
        text=text.replace("’","'")
        words=text.split()
        w=[len(re.sub(r"\W","",x))+2+(4 if re.search(r"[,.;:?!]$",x) else 0) for x in words]
        tot=sum(w); cur=start
        for x,wt in zip(words,w):
            d=dur*wt/tot
            ev.append((cur,cur+d,x.strip('"“”'))); cur+=d
    hdr="""[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 2

[V4+ Styles]
Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding
Style: W,Inter,120,&H00303030,&H00303030,&H00303030,&H00000000,1,0,0,0,100,100,0,0,1,0,0,8,40,40,170,1

[Events]
Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
"""
    lines=[]
    for i,(a,b,x) in enumerate(ev):
        b=min(b, ev[i+1][0]) if i+1<len(ev) else b
        lines.append(f"Dialogue: 0,{t(a)},{t(b)},W,,0,0,0,,{x}")
    open(f"{ROOT}/out/{v}.ass","w",encoding="utf-8").write(hdr+"\n".join(lines)+"\n")
for v in sys.argv[1:]: build(v)
