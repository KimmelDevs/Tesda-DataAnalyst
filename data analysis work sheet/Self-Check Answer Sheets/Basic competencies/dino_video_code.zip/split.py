import numpy as np, json
from PIL import Image, ImageDraw
d="/mnt/user-data/attachments/d2f52b8e-0010-5024-b80a-d846ea5318d5/"
files="7c15345e 38b0ba21 c81a04d1 2fb6a1eb 6ee108e9 f4f2a702 abfc0794 5014f9c8 422c8331 44997b5f d0417a16 9448066e 33ad9251 32010f52 a8bc472e 34a60589 101e85a8 e2a392cf".split()
names="06_S1 06_S2 07_S1 07_S2 08_S2 08_S1 09_S1 09_S2 01_S1 01_S2 02_S1 02_S2 03_S1 03_S2 04_S1 04_S2 05_S1 05_S2".split()
def best(p,lo,hi):
    s=np.convolve(p[lo:hi],np.ones(9)/9,'same'); return lo+int(np.argmin(s))
B={}
for n,nm in zip(files,names):
    im=Image.open(d+n+"-image.png").convert("RGB"); a=np.asarray(im)
    bg=np.median(np.concatenate([a[:20,:20].reshape(-1,3),a[:20,-20:].reshape(-1,3)]),axis=0)
    m=(np.abs(a.astype(int)-bg).sum(2)>60); H,W=m.shape
    ry=best(m.sum(1),int(H*.4),int(H*.6)); boxes=[]
    for (y0,y1) in ((0,ry),(ry,H)):
        sub=m[y0:y1]; cp=sub.sum(0)
        c1=best(cp,int(W*.25),int(W*.42)); c2=best(cp,int(W*.58),int(W*.75))
        for (x0,x1) in ((0,c1),(c1,c2),(c2,W)):
            c=sub[:,x0:x1]; ys=np.where(c.sum(1)>3)[0]; xs=np.where(c.sum(0)>3)[0]
            boxes.append((x0+int(xs[0])-6,y0+int(ys[0])-6,int(xs[-1]-xs[0])+12,int(ys[-1]-ys[0])+12))
    B[nm]=[(max(0,x),max(0,y),w,h) for x,y,w,h in boxes]; im.save(f"raw/{nm}.png")
json.dump(B,open("boxes.json","w"))
order=sorted(B)
sh=Image.new("RGB",(840*3,472*6),"white")
for i,nm in enumerate(order):
    im=Image.open(f"raw/{nm}.png"); dr=ImageDraw.Draw(im)
    for k,(x,y,w,h) in enumerate(B[nm]): dr.rectangle((x,y,x+w,y+h),outline="red",width=4)
    dr.rectangle((0,0,150,40),fill="white"); dr.text((8,10),nm,fill="red")
    sh.paste(im.resize((840,472)),((i%3)*840,(i//3)*472))
sh.save("chk/boxes.jpg",quality=72)
