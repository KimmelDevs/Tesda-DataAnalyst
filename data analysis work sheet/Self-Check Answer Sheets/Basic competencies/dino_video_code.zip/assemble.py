import subprocess, sys, os
sys.path.insert(0,"/home/claude/work/b5")
from cfg import V, ROOT
PY=f"{ROOT}/repo/.venv/bin/python"
for v in sys.argv[1:]:
    if os.path.exists(f"{ROOT}/b5/out/{V[v][1]}_short.mp4"): continue
    d=f"{ROOT}/b5/out/{v}"
    clips=[f"{d}/s{s}_o{o}.mp4" for s in (1,2) for o in range(1,7)]
    assert all(os.path.exists(c) for c in clips),"missing"
    silent=f"{d}/silent.mp4"
    subprocess.run([PY,f"{ROOT}/repo/scripts/merge_scenes.py","--inputs",*clips,"--output",silent],check=True,capture_output=True)
    sub=f"{d}/sub.mp4"; srt=f"{ROOT}/b5/{V[v][0]}.srt"
    style="FontName=Inter SemiBold,FontSize=8,PrimaryColour=&H404040&,Outline=0,Shadow=0,Alignment=6,MarginV=16,MarginL=14,MarginR=14"
    subprocess.run(["ffmpeg","-v","error","-y","-i",silent,"-vf",f"ass={ROOT}/b5/out/{v}.ass,scale=1080:1920,fps=30","-c:v","libx264","-crf","19","-pix_fmt","yuv420p","-an",sub],check=True)
    if not os.path.exists(f"{ROOT}/b5/outro.mp4"): subprocess.run(["python3",f"{ROOT}/b5/outro.py",f"{ROOT}/b5/outro.mp4"],check=True)
    lst=f"{d}/list.txt"; open(lst,"w").write(f"file '{sub}'\nfile '{ROOT}/b5/outro.mp4'\n")
    cat=f"{d}/cat.mp4"
    subprocess.run(["ffmpeg","-v","error","-y","-f","concat","-safe","0","-i",lst,"-c:v","libx264","-crf","19","-pix_fmt","yuv420p",cat],check=True)
    out=f"{ROOT}/b5/out/{V[v][1]}_short.mp4"
    subprocess.run(["ffmpeg","-v","error","-y","-i",cat,"-i",f"{ROOT}/b5/tts/{v}.wav","-map","0:v","-map","1:a","-c:v","copy","-c:a","aac","-b:a","192k","-shortest",out],check=True)
    print("ASSEMBLED",out,flush=True)
