import math, subprocess, sys
from PIL import Image, ImageDraw, ImageFont
W,H,FPS,DUR=1080,1920,30,5.0
BG=(245,235,215); INK=(58,58,58); BLUE=(47,111,214); ORANGE=(240,110,40); RED=(230,33,23)
FB="/usr/share/fonts/opentype/inter/Inter-Bold.otf"
def thumb():
    S=3; im=Image.new("RGBA",(600*S,600*S),(0,0,0,0)); d=ImageDraw.Draw(im)
    def rr(b,r,fill): d.rounded_rectangle([v*S for v in b],r*S,fill=fill,outline=INK,width=9*S//3)
    rr((260,40,370,320),52,(255,248,232))      # thumb
    rr((180,230,560,570),64,(255,248,232))     # palm
    for y in (350,430,510): d.line([(330*S,y*S),(540*S,y*S)],fill=INK,width=6*S)
    rr((30,250,170,580),28,BLUE)               # cuff
    return im.resize((600,600),Image.LANCZOS)
def bell():
    S=3; im=Image.new("RGBA,".strip(","),(300*S,300*S),(0,0,0,0)); d=ImageDraw.Draw(im)
    Y=(242,176,30)
    d.pieslice([70*S,50*S,230*S,250*S],180,360,fill=Y,outline=INK,width=8*S)
    d.polygon([(70*S,150*S),(230*S,150*S),(262*S,226*S),(38*S,226*S)],fill=Y,outline=INK)
    d.line([(70*S,150*S),(38*S,226*S),(262*S,226*S),(230*S,150*S)],fill=INK,width=8*S)
    d.ellipse([125*S,12*S,175*S,62*S],fill=Y,outline=INK,width=8*S)
    d.ellipse([122*S,232*S,178*S,288*S],fill=ORANGE,outline=INK,width=8*S)
    return im.resize((300,300),Image.LANCZOS)
def cursor():
    S=3; im=Image.new("RGBA",(120*S,160*S),(0,0,0,0)); d=ImageDraw.Draw(im)
    pts=[(10,10),(10,120),(38,95),(60,145),(80,136),(58,88),(95,88)]
    d.polygon([(x*S,y*S) for x,y in pts],fill=(255,255,255),outline=INK); d.line([(x*S,y*S) for x,y in pts+[pts[0]]],fill=INK,width=7*S)
    return im.resize((120,160),Image.LANCZOS)
T,B,C=thumb(),bell(),cursor()
def ease_back(x):
    x=max(0,min(1,x)); c1=1.9; c3=c1+1; return 1+c3*(x-1)**3+c1*(x-1)**2
def paste(img,sp,cx,cy,scale=1.0,rot=0):
    s=sp.resize((max(1,int(sp.width*scale)),max(1,int(sp.height*scale))),Image.LANCZOS)
    if rot: s=s.rotate(rot,resample=Image.BICUBIC,expand=True)
    img.alpha_composite(s,(int(cx-s.width/2),int(cy-s.height/2)))
def font(sz): return ImageFont.truetype(FB,sz)
def text_c(d,xy,t,sz,fill,scale=1.0):
    f=font(int(sz*scale)); d.text(xy,t,font=f,fill=fill,anchor="mm")
def frame(t):
    img=Image.new("RGBA",(W,H),BG+(255,)); d=ImageDraw.Draw(img)
    # like
    s=ease_back(t/0.5)
    if t>1.0 and t<1.6: u=(t-1.0)/0.6; s*=1-0.18*math.sin(math.pi*u)
    if t>0: paste(img,T,540,640,1.0*s*1.0)
    if 1.0<t<1.7:
        u=(t-1.0)/0.7
        for k in range(8):
            a=k*math.pi/4+0.2; r1=330+60*u; r2=r1+70*(1-u)
            d.line([(540+r1*math.cos(a),640+r1*math.sin(a)),(540+r2*math.cos(a),640+r2*math.sin(a))],fill=ORANGE,width=10)
    if t>0.5: text_c(d,(540,1010),"LIKE",120,INK,ease_back((t-0.5)/0.4))
    # subscribe button
    clicked=t>=3.2
    if t>1.5:
        s=ease_back((t-1.5)/0.5)
        if 3.2<=t<3.45: s*=0.92
        w,h=int(640*s),int(170*s); cx,cy=470,1290
        d.rounded_rectangle([cx-w//2,cy-h//2,cx+w//2,cy+h//2],int(40*s),fill=(207,203,192) if clicked else RED,outline=INK,width=6)
        text_c(d,(cx,cy),"SUBSCRIBED" if clicked else "SUBSCRIBE",(62 if clicked else 70),INK if clicked else (255,255,255),s)
    if t>1.8:
        s=ease_back((t-1.8)/0.5); rot=0
        if t>3.3: u=t-3.3; rot=28*math.exp(-1.2*u)*math.sin(14*u)
        paste(img,B,880,1290-10,0.62*s,rot)
        if t>3.3 and t<4.6:
            for sg in (-1,1):
                for k in (0,1):
                    x=880+sg*(105+28*k); d.arc([x-30,1250-30*0,x+30,1330],(-50 if sg>0 else 130),(50 if sg>0 else 230),fill=ORANGE,width=7)
    # cursor
    if 2.2<t<4.4:
        u=min(1,(t-2.2)/1.0); u=u*u*(3-2*u)
        x=900+(520-900)*u; y=1650+(1320-1650)*u
        if t>3.45: x+=(t-3.45)*60; y+=(t-3.45)*90
        paste(img,C,x+30,y+45,1.0)
    if clicked and t<3.7:
        u=(t-3.2)/0.5
        d.ellipse([520-60*u-10,1310-60*u-10,520+60*u+10,1310+60*u+10],outline=BLUE,width=6)
    return img.convert("RGB")
if __name__=="__main__":
    out=sys.argv[1]
    p=subprocess.Popen(["ffmpeg","-v","error","-y","-f","rawvideo","-pix_fmt","rgb24","-s",f"{W}x{H}","-r",str(FPS),"-i","-","-c:v","libx264","-crf","18","-pix_fmt","yuv420p",out],stdin=subprocess.PIPE)
    for i in range(int(DUR*FPS)): p.stdin.write(frame(i/FPS).tobytes())
    p.stdin.close(); p.wait()
