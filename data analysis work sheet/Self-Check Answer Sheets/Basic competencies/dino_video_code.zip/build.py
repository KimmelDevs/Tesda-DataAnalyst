import json, subprocess, sys, os
import numpy as np
from PIL import Image
from multiprocessing import Pool
sys.path.insert(0,"/home/claude/work/b5")
from cfg import *
PY=f"{ROOT}/repo/.venv/bin/python"; REN=f"{ROOT}/repo/scripts/render_stream_whiteboard.py"; HAND=f"{ROOT}/repo/assets/drawing-hand.png"
CW,CH=1080,1920; CX,CY,MAXW,MAXH,MAXS=540,720,1000,950,2.0; SLOT=5000
def paper(im):
    a=np.asarray(im.convert("RGB")); p=[a[:30,:30],a[:30,-30:],a[-30:,:30],a[-30:,-30:]]
    return tuple(int(v) for v in np.median(np.concatenate([q.reshape(-1,3) for q in p]),axis=0))
def jobs(v):
    out=f"{ROOT}/b5/out/{v}"; os.makedirs(out,exist_ok=True); J=[]
    for si in (1,2):
        sc=f"{v}_S{si}"; im=Image.open(f"{ROOT}/b5/raw/{sc}.png").convert("RGB"); bg=paper(im)
        for i,(x,y,w,h) in enumerate(BOXES[sc]):
            crop=Image.open(f"{ROOT}/b5/crops/{sc}_{i+1}.png").convert('RGB'); w,h=crop.size; s=min(MAXW/w,MAXH/h,MAXS); nw,nh=int(w*s),int(h*s)
            crop=crop.resize((nw,nh),Image.LANCZOS); canvas=Image.new("RGB",(CW,CH),bg)
            x0,y0=CX-nw//2,CY-nh//2; canvas.paste(crop,(x0,y0)); base=f"{out}/s{si}_o{i+1}"; canvas.save(base+".png")
            pad=24
            a={"sceneId":f"s{si}o{i+1}","canvas":{"width":CW,"height":CH},"storyBasis":v,"sceneDurationMs":SLOT,"elements":[{
              "id":f"o{i+1}","label":f"object {i+1}","sequence":1,"narrativeRole":"对象","subtitle":"","type":"object",
              "region":{"x":max(0,x0-pad),"y":max(0,y0-pad),"width":min(CW,nw+2*pad),"height":min(CH,nh+2*pad)},
              "reveal":{"direction":"left_to_right","startMs":200,"durationMs":SLOT-900,"maskPaddingPx":18,"protectedRegions":[]},
              "handPath":{"start":[x0,CY],"end":[x0+nw,CY],"easing":"easeInOut"}}]}
            json.dump(a,open(base+".annotation.json","w"),ensure_ascii=False); J.append(base)
    return J
def ok(p): return os.path.exists(p) and subprocess.run(["ffprobe","-v","error","-show_entries","format=duration","-of","csv=p=0",p],capture_output=True).returncode==0
def render(b):
    if ok(b+".mp4"): return b
    subprocess.run([PY,REN,b+".png",b+".annotation.json",b+".mp4",HAND,"--fps","30","--cap-long-edge","1920"],check=True,capture_output=True); return b
if __name__=="__main__":
    for v in sys.argv[1:]:
        J=jobs(v)
        with Pool(2) as p:
            for k,b in enumerate(p.imap_unordered(render,J)): print(v,k+1,"/",len(J),flush=True)
    print("ALL DONE",flush=True)
