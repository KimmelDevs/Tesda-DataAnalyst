RUN ORDER (hand-draw Shorts)
1. split.py       find the 6 boxes in each 3x2 image -> boxes.json
2. crop_clean.py  cut each box out and clean it -> crops/
3. build.py 01    make the 12 hand-draw clips (drawing hand reveal) for one video
4. narrate_t.py 01  Kokoro voice + outro line + word timing json
5. mkass.py 01    one-word-at-a-time subtitle file
6. assemble.py 01 merge 12 clips = 60 s, burn subtitles, add outro (outro.py), add voice
Paths point at my sandbox (/home/claude/work/...). The drawing hand comes from the srt-whiteboard-animation tool (render_stream_whiteboard.py, merge_scenes.py), not included here.
